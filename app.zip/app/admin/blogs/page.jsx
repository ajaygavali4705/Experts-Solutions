"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, Trash2, X } from "lucide-react";
import AdminNavbar from "../navbar";

export default function AdminBlogs() {
  const router = useRouter();
  const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL;

  useEffect(() => {
    const isCookie = document.cookie.includes("adminLoggedIn=true");
    if (!isCookie) {
      router.replace("/admin");
    } else {
      fetchBlogs(); // 👈 FETCH BLOGS ON PAGE LOAD
    }
  }, []);

  const token =
    typeof window !== "undefined" ? localStorage.getItem("adminToken") : "";

  const handleLogout = () => {
    localStorage.removeItem("adminLoggedIn");
    localStorage.removeItem("adminToken");

    document.cookie =
      "adminLoggedIn=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;";

    router.replace("/admin");
  };

  // BLOG DATA
  const [blogs, setBlogs] = useState([]);

  // FORM CONTROLS
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [preview, setPreview] = useState(null);

  const [viewImage, setViewImage] = useState(null);

  // ---------------------------------------------------------------------------
  // ✅ FETCH ALL BLOGS (GET)
  // ---------------------------------------------------------------------------
  const fetchBlogs = async () => {
    try {
      const res = await fetch(`${BACKEND_URL}/api/blogs`);
      const data = await res.json();

      if (data.success) {
        setBlogs(data.data);
      }
    } catch (error) {
      console.error("Error fetching blogs", error);
    }
  };

  // ---------------------------------------------------------------------------
  // ✅ ADD BLOG (POST)
  // ---------------------------------------------------------------------------
  const handleAddBlog = async () => {
    if (!title || !description || !imageFile)
      return alert("Please fill all fields");

    const formData = new FormData();
    formData.append("title", title);
    formData.append("description", description);
    formData.append("image", imageFile);

    try {
      const res = await fetch(`${BACKEND_URL}/api/blogs/add`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`, // 🔐 AUTH TOKEN
        },
        body: formData,
      });

      const data = await res.json();

      if (data.success) {
        alert("Blog Added Successfully");
        fetchBlogs(); // refresh blogs

        // Reset form
        setTitle("");
        setDescription("");
        setImageFile(null);
        setPreview(null);
        setShowForm(false);
      } else {
        alert(data.message || "Error adding blog");
      }
    } catch (error) {
      console.error("Error adding blog:", error);
      alert("Failed to add blog");
    }
  };

  // ---------------------------------------------------------------------------
  // ✅ DELETE BLOG (DELETE)
  // ---------------------------------------------------------------------------
  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this blog?")) return;

    try {
      const res = await fetch(`${BACKEND_URL}/api/blogs/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`, // 🔐 AUTH TOKEN
        },
      });

      const data = await res.json();

      if (data.success) {
        alert("Blog Deleted Successfully");
        fetchBlogs(); // refresh list
      } else {
        alert("Error deleting blog");
      }
    } catch (error) {
      console.error("Delete error:", error);
      alert("Failed to delete");
    }
  };

  // ---------------------------------------------------------------------------

  return (
    <>
      <AdminNavbar onLogout={handleLogout} />

      <div className="p-6">
        {/* Title + Add Button */}
        <div className="flex justify-between items-center mb-6 w-[70%] mx-auto">
          <h1 className="text-3xl font-bold">Blogs Management</h1>

          <button
            onClick={() => setShowForm(!showForm)}
            className="bg-[#87CEEB] text-white px-5 py-2 rounded-lg shadow hover:bg-[#87CEEB]/90 transition"
          >
            + Add Blog
          </button>
        </div>

        {/* Add Blog Form */}
        {showForm && (
          <div className="bg-white p-5 rounded-lg shadow mb-6 border w-[70%] mx-auto border-blue-300">
            <h3 className="text-xl font-semibold mb-3">Add Blog</h3>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="Enter Blog Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="border p-2 rounded w-full"
              />

              <textarea
                placeholder="Enter Blog Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="border p-2 rounded w-full h-28"
              ></textarea>

              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  setImageFile(e.target.files[0]);
                  setPreview(URL.createObjectURL(e.target.files[0]));
                }}
                className="border p-2 rounded w-full"
              />

              {preview && (
                <img
                  src={preview}
                  className="h-32 w-auto object-cover rounded border shadow"
                />
              )}

              <button
                onClick={handleAddBlog}
                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition"
              >
                Add Blog
              </button>
            </div>
          </div>
        )}

        {/* BLOG TABLE */}
        <div className="overflow-x-auto bg-white rounded-xl shadow-xl border w-[70%] mx-auto">
          <table className="min-w-full border-collapse">
            <thead>
              <tr className="bg-[#8B1F2F] text-white">
                <th className="px-4 py-3 text-left">ID</th>
                <th className="px-4 py-3 text-left">Image</th>
                <th className="px-4 py-3 text-left">Title</th>
                <th className="px-4 py-3 text-left">Description</th>
                <th className="px-4 py-3 text-left">Actions</th>
              </tr>
            </thead>

            <tbody>
              {blogs.length === 0 ? (
                <tr>
                  <td className="p-4 text-center text-gray-500" colSpan="5">
                    No Blogs Added Yet
                  </td>
                </tr>
              ) : (
                blogs.map((blog, index) => (
                  <tr key={blog._id} className="border-b hover:bg-blue-50">
                    <td className="px-4 py-3 font-medium">{index + 1}</td>

                    <td className="px-4 py-3">
                      <img
                        src={`${BACKEND_URL}/uploads/blogs/${blog.image.fileName}`}
                        className="h-20 w-36 object-cover rounded-lg shadow border"
                      />
                    </td>

                    <td className="px-4 py-3 font-medium">{blog.title}</td>

                    <td className="px-4 py-3">{blog.description}</td>

                    <td className="px-4 py-3 flex items-center gap-3">
                      <button
                        onClick={() =>
                          setViewImage(
                            `${BACKEND_URL}/uploads/blogs/${blog.image.fileName}`
                          )
                        }
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Eye size={22} />
                      </button>

                      <button
                        onClick={() => handleDelete(blog._id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 size={22} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* VIEW IMAGE MODAL */}
      {viewImage && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-md flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded-lg shadow-xl relative max-w-[80%] max-h-[80%]">
            <button
              onClick={() => setViewImage(null)}
              className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1"
            >
              <X size={18} />
            </button>

            <img
              src={viewImage}
              className="max-w-full max-h-[75vh] object-contain rounded"
            />
          </div>
        </div>
      )}
    </>
  );
}
