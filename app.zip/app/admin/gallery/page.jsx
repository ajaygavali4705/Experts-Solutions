"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, Trash2, X } from "lucide-react";
import AdminNavbar from "../navbar";

export default function AdminGallery() {
  const router = useRouter();
  const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL;

  useEffect(() => {
    const isCookie = document.cookie.includes("adminLoggedIn=true");
    if (!isCookie) {
      router.replace("/admin");
    } else {
      fetchGallery();
    }
  }, []);

  const token =
    typeof window !== "undefined" ? localStorage.getItem("adminToken") : "";

  const handleLogout = () => {
    localStorage.removeItem("adminLoggedIn");
    localStorage.removeItem("adminToken");

    document.cookie =
      "adminLoggedIn=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;";

    router.replace("/admin");
  };

  // -----------------------------
  //   STATES
  // -----------------------------
  const [gallery, setGallery] = useState([]);

  // image form
  const [showImageForm, setShowImageForm] = useState(false);
  const [imageName, setImageName] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [preview, setPreview] = useState(null);

  // video form
  const [showVideoForm, setShowVideoForm] = useState(false);
  const [videoName, setVideoName] = useState("");
  const [videoFile, setVideoFile] = useState(null);

  const [viewImage, setViewImage] = useState(null);

  // -----------------------------
  //   FETCH GALLERY
  // -----------------------------
  const fetchGallery = async () => {
    try {
      const res = await fetch(`${BACKEND_URL}/api/gallery`);
      const data = await res.json();

      if (data.success) setGallery(data.data);
    } catch (error) {
      console.error("Error fetching gallery", error);
    }
  };

  // -----------------------------
  //   ADD IMAGE
  // -----------------------------
  const handleAddImage = async () => {
    if (!imageName || !imageFile)
      return alert("Please fill all fields");

    const formData = new FormData();
    formData.append("name", imageName);
    formData.append("image", imageFile);

    try {
      const res = await fetch(`${BACKEND_URL}/api/gallery/add`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      const data = await res.json();

      if (data.success) {
        alert("Image Added Successfully");
        fetchGallery();

        setImageName("");
        setImageFile(null);
        setPreview(null);
        setShowImageForm(false);
      } else {
        alert(data.message || "Error adding image");
      }
    } catch (error) {
      console.error("Add Error:", error);
      alert("Failed to add image");
    }
  };

  // -----------------------------
  //   ADD VIDEO
  // -----------------------------
  const handleAddVideo = async () => {
    if (!videoName || !videoFile)
      return alert("Please fill all fields");

    const formData = new FormData();
    formData.append("name", videoName);
    formData.append("video", videoFile);

    try {
      const res = await fetch(`${BACKEND_URL}/api/gallery/add-video`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      const data = await res.json();

      if (data.success) {
        alert("Video Added Successfully");
        fetchGallery();

        setVideoName("");
        setVideoFile(null);
        setShowVideoForm(false);
      } else {
        alert(data.message || "Error adding video");
      }
    } catch (error) {
      console.error("Video Add Error:", error);
      alert("Failed to add video");
    }
  };

  // -----------------------------
  //   DELETE ITEM
  // -----------------------------
  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this item?")) return;

    try {
      const res = await fetch(`${BACKEND_URL}/api/gallery/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();

      if (data.success) {
        alert("Deleted");
        fetchGallery();
      }
    } catch (error) {
      console.error("Delete Error:", error);
    }
  };

  return (
    <>
      <AdminNavbar onLogout={handleLogout} />

      <div className="p-6">
        {/* Title + Buttons */}
        <div className="flex justify-between items-center mb-6 w-[70%] mx-auto">
          <h1 className="text-3xl font-bold">Gallery Management</h1>

          <div className="flex gap-3">
            <button
              onClick={() => {
                setShowImageForm(!showImageForm);
                setShowVideoForm(false);
              }}
              className="bg-[#87CEEB] text-white px-5 py-2 rounded-lg shadow hover:bg-[#87CEEB]/90 transition"
            >
              + Add Image
            </button>

            <button
              onClick={() => {
                setShowVideoForm(!showVideoForm);
                setShowImageForm(false);
              }}
              className="bg-[#8B1F2F] text-white px-5 py-2 rounded-lg shadow hover:bg-[#8B1F2F]/90 transition"
            >
              + Add Video
            </button>
          </div>
        </div>

        {/* Add Image Form */}
        {showImageForm && (
          <div className="bg-white p-5 rounded-lg shadow mb-6 border w-[70%] mx-auto border-blue-300">
            <h3 className="text-xl font-semibold mb-3">Add Image</h3>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="Enter Image Name"
                value={imageName}
                onChange={(e) => setImageName(e.target.value)}
                className="border p-2 rounded w-full"
              />

              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  setImageFile(e.target.files[0]);
                  setPreview(URL.createObjectURL(e.target.files[0]));
                }}
                className="border p-2 rounded w-full"
              />

              {preview && (
                <img
                  src={preview}
                  className="h-32 w-auto object-cover rounded border shadow"
                />
              )}

              <button
                onClick={handleAddImage}
                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition"
              >
                Add Image
              </button>
            </div>
          </div>
        )}

        {/* Add Video Form */}
        {showVideoForm && (
          <div className="bg-white p-5 rounded-lg shadow mb-6 border w-[70%] mx-auto border-red-300">
            <h3 className="text-xl font-semibold mb-3">Add Video</h3>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="Enter Video Name"
                value={videoName}
                onChange={(e) => setVideoName(e.target.value)}
                className="border p-2 rounded w-full"
              />

              <input
                type="file"
                accept="video/*"
                onChange={(e) => setVideoFile(e.target.files[0])}
                className="border p-2 rounded w-full"
              />

              <button
                onClick={handleAddVideo}
                className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition"
              >
                Add Video
              </button>
            </div>
          </div>
        )}

        {/* TABLE */}
        <div className="overflow-x-auto bg-white rounded-xl shadow-xl border w-[70%] mx-auto">
          <table className="min-w-full border-collapse">
            <thead>
              <tr className="bg-[#8B1F2F] text-white">
                <th className="px-4 py-3 text-left">ID</th>
                <th className="px-4 py-3 text-left">Preview</th>
                <th className="px-4 py-3 text-left">Name</th>
                <th className="px-4 py-3 text-left">Type</th>
                <th className="px-4 py-3 text-left">Actions</th>
              </tr>
            </thead>

            <tbody>
              {gallery.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-center p-4 text-gray-500">
                    No Items Added Yet
                  </td>
                </tr>
              ) : (
                gallery.map((item, index) => (
                  <tr key={item._id} className="border-b hover:bg-blue-50">
                    <td className="px-4 py-3 font-medium">{index + 1}</td>

                    <td className="px-4 py-3">
                      {item.type === "image" ? (
                        <img
                          src={`${BACKEND_URL}/uploads/gallery/${item.image.fileName}`}
                          className="h-20 w-36 object-cover rounded-lg shadow border"
                        />
                      ) : (
                        <video
                          src={`${BACKEND_URL}/uploads/gallery/${item.video.fileName}`}
                          className="h-20 w-36 rounded-lg shadow border"
                          controls
                        />
                      )}
                    </td>

                    <td className="px-4 py-3 font-medium">{item.name}</td>

                    <td className="px-4 py-3 font-medium uppercase">
                      {item.type}
                    </td>

                    <td className="px-4 py-3 flex items-center gap-3">
                      <button
                        onClick={() =>
                          setViewImage(
                            item.type === "image"
                              ? `${BACKEND_URL}/uploads/gallery/${item.image.fileName}`
                              : `${BACKEND_URL}/uploads/gallery/${item.video.fileName}`
                          )
                        }
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Eye size={22} />
                      </button>

                      <button
                        onClick={() => handleDelete(item._id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 size={22} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* VIEW MODAL */}
      {viewImage && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-md flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded-lg shadow-xl relative max-w-[80%] max-h-[80%]">
            <button
              onClick={() => setViewImage(null)}
              className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1"
            >
              <X size={18} />
            </button>

            {viewImage.endsWith(".mp4") ||
            viewImage.endsWith(".mov") ||
            viewImage.includes("video") ? (
              <video
                src={viewImage}
                className="max-w-full max-h-[75vh] rounded"
                controls
              />
            ) : (
              <img
                src={viewImage}
                className="max-w-full max-h-[75vh] object-contain rounded"
              />
            )}
          </div>
        </div>
      )}
    </>
  );
}
